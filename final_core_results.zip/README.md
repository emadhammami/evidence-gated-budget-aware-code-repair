# Publication Experimental Artifact

This archive contains the experimental data used in the paper:

"Evidence-Guided Budget Allocation for Multi-Stage Large Language Model Orchestration"

## Contents

- `core_runs.csv`: the 240 completed non-pilot runs used in the reported analysis.
- `raw/`: one raw JSON telemetry file for each of the 240 reported runs.
- `experiment_git_commit.txt`: implementation commit used for all reported experiments.
- `python_version.txt`: Python version used when packaging the artifact.
- `requirements-final.txt`: installed Python packages and versions.

## Reported Conditions

The core evaluation contains exactly 240 runs:

- Single-shot @ 4000 tokens: 40
- PEC @ 4000 tokens: 40
- PEVC @ 4000 tokens: 40
- Evidence-Gated @ 4000 tokens: 40
- Evidence-Gated @ 2000 tokens: 40
- Evidence-Gated @ 1000 tokens: 40

The five-task infrastructure pilot and infrastructure-error attempts are excluded.

All 240 reported runs:
- have `run_status = completed`;
- have `is_pilot = false`;
- use experiment commit `93ce1a5901bf900033c8cc7c547b8e8926bb7103`;
- use provider-reported token counts;
- contain no budget violations.

The raw JSON files preserve detailed workflow, validation, model-call,
token-budget, and runtime telemetry for auditability.
